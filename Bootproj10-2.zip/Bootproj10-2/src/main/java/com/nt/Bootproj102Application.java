package com.nt;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.nt.controller.TeacherController;
import com.nt.model.Teacher;

@SpringBootApplication
public class Bootproj102Application {

	public static void main(String[] args) {
		ApplicationContext ctx =SpringApplication.run(Bootproj102Application.class, args);
		TeacherController tt= ctx.getBean("Controller",TeacherController.class);
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("enter the your name ");
			String name = s.next();
			System.out.println("enter the your qualifacton");
			String Qualification = s.next();
			System.out.println("enter the your salary ");
			double salary= s.nextDouble();
			System.out.println("enter the your subject");
			String subject = s.next();
			
			
			Teacher tc =new Teacher();
			tc.setName(name);
			tc.setQualification(Qualification);
			tc.setSalary(salary);
			tc.setSubject(subject);
			String msg = tt.registerData(tc);
			System.out.println(msg);
			List<Teacher>list=tt.showAllTeacher();
			list.forEach(tc1->{
				System.out.println(tc1);
			});
			System.out.println("search by the id ");
			int id = s.nextInt();
			Optional<Teacher>op = tt.showTeacherById(id);
	
	if(op.isPresent()) {
	tc=op.get();
	System.out.println(tc.getClass());
	System.out.println(tc.getName());
	System.out.println(tc.getQualification());
	System.out.println(tc.getSubject());
	System.out.println("search by the name");
	String name1=s.next();
	List<Teacher> list1 = tt.ShowTeacherByName(name1);
	list1.forEach(tc2->{
		
	System.out.println(tc2);
		});
		System.out.println("delete by the ids");
		int s1 =s.nextInt();
		int s2=s.nextInt();
		ArrayList<Integer> ids = new ArrayList<>();
		ids.add(s1);
		ids.add(s2);
		String msg1=tt.deleteTeacherByIds(ids); 
		System.out.println(msg1);
		System.out.println("update your id" );
		int id1=s.nextInt();
		Teacher t = tt.updateTeacherData(id1, tc);
		
		System.out.println("update your name");
		String name2=s.next();
		System.out.println("update your qualification");
		String Qualification1 =s.next();
		System.out.println("update your salary");
		double salary1=s.nextDouble();
		System.out.println("update your subject");
		String subject1 =s.next();
		
		t.setName(name2);
		t.setQualification(Qualification1);
		t.setSalary(salary1);
		t.setSubject(subject1);		
	}

}
		}
}
