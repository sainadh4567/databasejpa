package com.nt.model;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;

@Entity
@Table(name="TEACHER_DATA")
@Data
public class Teacher {
	@Column(name="TEACH_ID")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private Integer id;
	@Column(name="TEACH_NAME",length=25)
private String name;
	@Column(name="SUBJECT")
private String subject;
	@Transient
	@Column(name="QUALIFICATION",length=20)
private String qualification;
	
	@Column(name="SALARY")
private Double salary;

}
