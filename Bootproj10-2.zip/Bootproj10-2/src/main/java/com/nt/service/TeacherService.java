package com.nt.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.nt.Dao.TeacherDao;
import com.nt.model.Teacher;
@Service
public class TeacherService  implements  ITeacherService{
	@Autowired
	private TeacherDao teachdao;
	public String registerTeacherData(Teacher tc) {
		System.out.println("save data"+tc.getId());
		Teacher teach = teachdao.saveAndFlush(tc);
		return teach.getId()+"data inserted" ;
	}
	public List<Teacher> showAllData(){
		return teachdao.findAll() ;
		
	}
public Optional<Teacher> showDataByIds(int id) {
	
	return teachdao.findById(id);
	
}
public List<Teacher> ShowDataByNames(String  Name){
	return teachdao.findByName(Name) ;
	
}

public String removeTeachersByIdsInBatch(Iterable<Integer> ids) {
	
	   List<Teacher>  list=teachdao.findAllById(ids);
	   int count=list.size();
	   if(count!=0) {
		  
		   teachdao.deleteAllByIdInBatch(ids);
		   return count+"  no.of records  deleted"; 
	   }
	   return  "No records found for deletion";
}

public Teacher updateData(int id, Teacher updatedTeacher) {
    Optional<Teacher> opt = teachdao.findById(id);
    if (opt.isPresent()) {
        Teacher existing = opt.get();
        
      
        existing.setName(updatedTeacher.getName());
        existing.setSubject(updatedTeacher.getSubject());
        existing.setQualification(updatedTeacher.getQualification());
        existing.setSalary(updatedTeacher.getSalary());
        
     
        return teachdao.save(existing);
    } else {
        throw new RuntimeException("Teacher with ID " + id + " not found");
    }
}

	
}


