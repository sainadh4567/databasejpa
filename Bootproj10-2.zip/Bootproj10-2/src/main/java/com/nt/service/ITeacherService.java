package com.nt.service;



import java.util.List;
import java.util.Optional;

import com.nt.model.Teacher;

public interface ITeacherService {
	
	public String registerTeacherData(Teacher tc);
	public List<Teacher> showAllData();
	public Optional<Teacher> showDataByIds(int id);
	public List<Teacher> ShowDataByNames(String  Name);
	public String removeTeachersByIdsInBatch(Iterable<Integer> ids);
	public Teacher updateData(int id, Teacher updatedTeacher);
}
