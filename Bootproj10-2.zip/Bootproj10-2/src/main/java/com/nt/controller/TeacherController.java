package com.nt.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nt.model.Teacher;
import com.nt.service.TeacherService;
@Controller("Controller")
public class TeacherController {
	@Autowired
	TeacherService teachSer;
public String registerData(Teacher tc) {

	return teachSer.registerTeacherData(tc);
	
}
public List<Teacher> showAllTeacher(){
	return teachSer.showAllData();
	}
public Optional<Teacher> showTeacherById(int id) {
	return teachSer.showDataByIds(id);
}
public List<Teacher> ShowTeacherByName(String name) {
	return teachSer.ShowDataByNames(name);
}


public String deleteTeacherByIds(Iterable<Integer> ids) {
	// TODO Auto-generated method stub
	return teachSer.removeTeachersByIdsInBatch(ids);
}
public Teacher updateTeacherData(int id ,Teacher tc) {
	return teachSer.updateData(id, tc);
}

}